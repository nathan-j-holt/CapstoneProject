﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectManagement.Secure
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // testShib.Text = Session["First_Name"].ToString();
        }
        protected void btnClientForm_Click(object sender, EventArgs e)
        {
            Response.Redirect("ClientApplication.aspx");
        }

        protected void btnProfessorDashboard_Click(object sender, EventArgs e)
        {
            Response.Redirect("secure/ProfessorDashboard.aspx");
        }
        protected void btnStudentDashboard_Click(object sender, EventArgs e)
        {
            Response.Redirect("secure/StudentDashboard.aspx");
        }

        protected void btnProposalStatus_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "showModal", "$('#proposalModal').modal('show');", true);
        }

        protected void btnLogIn_Click(object sender, EventArgs e)
        {
            Response.Redirect("secure/Login.aspx");
        }

        protected void btnCloseModal_Click(object sender, EventArgs e)
        {
            txtEmail.Text = "";
            lblEmailError.Visible = false;

            ScriptManager.RegisterStartupScript(this, GetType(), "CloseModalScript", "$('#proposalModal').modal('hide');", true);
        }
       
        protected void btnSubmitProposalStatus_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                string email = txtEmail.Text;

                DBConnect db = new DBConnect();

                string storedProcedureName = "Search_ClientEmail";

                SqlCommand cmd = new SqlCommand(storedProcedureName);
                cmd.CommandType = CommandType.StoredProcedure;

                // Add parameters if necessary
                cmd.Parameters.AddWithValue("@Client_Email", email);

                DataSet dataSet = db.GetDataSet(cmd);

                // Check if dataset is not null and contains at least one row
                if (dataSet != null && dataSet.Tables.Count > 0 && dataSet.Tables[0].Rows.Count > 0)
                {
                    // Store email, first name, and last name into session objects
                    string firstName = dataSet.Tables[0].Rows[0]["Client_First_Name"].ToString();
                    string lastName = dataSet.Tables[0].Rows[0]["Client_Last_Name"].ToString();
                    Session["Email"] = email;
                    Session["FirstName"] = firstName;
                    Session["LastName"] = lastName;

                    // Redirect to ApplicationStatus.aspx
                    Response.Redirect("ApplicationStatus.aspx");
                }
                else
                {
                    lblEmailError.Text = "No proposals found for that email.";
                    lblEmailError.Visible = true;

                    ScriptManager.RegisterStartupScript(this, GetType(), "showModal", "$('#proposalModal').modal('show');", true);
                }

            }
        }
    }
}
