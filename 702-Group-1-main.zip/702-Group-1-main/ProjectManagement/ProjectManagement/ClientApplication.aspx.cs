﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Data.SqlClient;

namespace ProjectManagement
{
    public partial class ClientApplication : System.Web.UI.Page
    {
        DBConnect objDB = new DBConnect();
        SqlCommand objCommand = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            bool isValid = true;
            lblCompanyError.Visible = false;
            lblLastNameError.Visible = false;
            lblOneError.Visible = false;
            lblTwoError.Visible = false;
            lblThreeError.Visible = false;
            lblFourError.Visible = false;
            lblFiveError.Visible = false;
            lblFiveOtherError.Visible = false;
            lblSixError.Visible = false;
            lblFirstNameError.Visible = false;
            lblPhoneError.Visible = false;
            lblEmailError.Visible = false;

            // Checks to see if they have entered their first name
            if (string.IsNullOrEmpty(txtFirstName.Text))
            {
                lblFirstNameError.ForeColor = System.Drawing.Color.Red;
                lblFirstNameError.Visible = true;
                lblFirstNameError.Text = "Please enter your first name";
                isValid = false;
            }

            // Checks to see if they have entered their last name
            if (string.IsNullOrEmpty(txtLastName.Text))
            {
                lblLastNameError.ForeColor = System.Drawing.Color.Red;
                lblLastNameError.Visible = true;
                lblLastNameError.Text = "Please enter your last name";
                isValid = false;
            }

            // Checks to see if they entered a company name
            if (string.IsNullOrEmpty(txtCompanyName.Text))
            {
                lblCompanyError.ForeColor = System.Drawing.Color.Red;
                lblCompanyError.Visible = true;
                lblCompanyError.Text = "Please enter a company name";
                isValid = false;
            }

            // Checks to see if they entered a valid email
            if (string.IsNullOrEmpty(txtEmail.Text))
            {
                lblEmailError.ForeColor = System.Drawing.Color.Red;
                lblEmailError.Visible = true;
                lblEmailError.Text = "Please enter an email";
                isValid = false;
            }

            // Check if phone number is empty
            if (string.IsNullOrEmpty(txtPhoneNumber.Text) || IsMaskOnly(txtPhoneNumber.Text))
            {
                lblPhoneError.ForeColor = System.Drawing.Color.Red;
                lblPhoneError.Visible = true;
                lblPhoneError.Text = "Please enter a phone number";
                isValid = false;
            }
            else
            {
                lblPhoneError.Visible = false; // Hide the phone error label if phone number is valid
            }

            // Check if txtQuestionOne is empty
            if (string.IsNullOrEmpty(txtQuestionOne.Text))
            {
                lblOneError.ForeColor = System.Drawing.Color.Red;
                lblOneError.Visible = true;
                lblOneError.Text = "Please enter a project title";
                isValid = false;
            }

            // Check if txtQuestionTwo is empty
            if (string.IsNullOrEmpty(txtQuestionTwo.Text))
            {
                lblTwoError.ForeColor = System.Drawing.Color.Red;
                lblTwoError.Visible = true;
                lblTwoError.Text = "Please enter a description of your project";
                isValid = false;
            }

            // Checks to see if at least one of the radio buttons are selected
            if (!rdoYes.Checked && !rdoNo.Checked)
            {
                lblThreeError.ForeColor = System.Drawing.Color.Red;
                lblThreeError.Visible = true;
                lblThreeError.Text = "Please select Yes or No";
                isValid = false;
            }

            // Checks to see if the client has selected a radio button for the type of product is selected
            if (!rdoMobileApp.Checked && !rdoWebTool.Checked)
            {
                lblFourError.ForeColor = System.Drawing.Color.Red;
                lblFourError.Visible = true;
                lblFourError.Text = "Please select a product/program you would like developed";
                isValid = false;
            }

            // Checks if they have selected an option for being able to meet
            if (!rdoYesToMeet.Checked && !rdoNoToMeet.Checked && !rdoOther.Checked)
            {
                lblFiveError.ForeColor = System.Drawing.Color.Red;
                lblFiveError.Visible = true;
                lblFiveError.Text = "Please select Yes, No, or Other";
                isValid = false;
            }

            // Checks to see if they have selected "Other" and entered in something into the text box
            else if (rdoOther.Checked && string.IsNullOrEmpty(txtOtherExplanation.Text))
            {
                lblFiveOtherError.ForeColor = System.Drawing.Color.Red;
                lblFiveOtherError.Visible = true;
                lblFiveOtherError.Text = "Please enter a reason for selecting other";
                isValid = false;
            }

            // Checks if they have selected an option for the development period
            if (!rdoDevelopmentYes.Checked && !rdoDevelopmentNo.Checked)
            {
                lblSixError.ForeColor = System.Drawing.Color.Red;
                lblSixError.Visible = true;
                lblSixError.Text = "Please select Yes or No";
                isValid = false;
            }

            // If all fields are not showing errors, add project to the database
            if (isValid == true)
            {
                string nonProfitSelection = rdoYes.Checked ? "Yes" : "No";
                string Platform = rdoMobileApp.Checked ? "Mobile App" : "Web Tool";
                string twoSemesters = rdoDevelopmentYes.Checked ? "Yes" : "No";

                string meetingFrequency = "";
                if (rdoYesToMeet.Checked)
                {
                    meetingFrequency = "Yes";
                }
                else if (rdoNoToMeet.Checked)
                {
                    meetingFrequency = "No";
                }
                else if (rdoOther.Checked)
                {
                    meetingFrequency = "Other: " + txtOtherExplanation.Text;
                }

                litUserInfo.Text = "<strong>Company Name:</strong> " + txtCompanyName.Text + "<br />";
                litUserInfo.Text += "<strong>First Name:</strong> " + txtFirstName.Text + "<br />";
                litUserInfo.Text += "<strong>Last Name:</strong> " + txtLastName.Text + "<br />";
                litUserInfo.Text += "<strong>Email:</strong> " + txtEmail.Text + "<br />";
                litUserInfo.Text += "<strong>Phone Number:</strong> " + txtPhoneNumber.Text + "<br />";
                litUserInfo.Text += "<strong>Title:</strong> " + txtQuestionOne.Text + "<br />";
                litUserInfo.Text += "<strong>Description:</strong> " + txtQuestionTwo.Text + "<br />";
                litUserInfo.Text += "<strong>Non-Profit?:</strong> " + nonProfitSelection + "<br />";
                litUserInfo.Text += "<strong>Platform:</strong> " + Platform + "<br />";
                litUserInfo.Text += "<strong>Biweekly meetings?:</strong> " + meetingFrequency + "<br />";
                litUserInfo.Text += "<strong>Available for two semesters?:</strong> " + twoSemesters + "<br />";


                ScriptManager.RegisterStartupScript(this, GetType(), "showModal", "$('#proposalModal').modal('show');", true);

            }
        }

        protected void rdoOther_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoOther.Checked)
            {
                lblQuestionFiveOther.Visible = true;
                txtOtherExplanation.Visible = true;
            }

            else
            {
                lblQuestionFiveOther.Visible = false;
                txtOtherExplanation.Visible = false;
            }
        }

        protected void rdoYesToMeet_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoYesToMeet.Checked)
            {
                lblQuestionFiveOther.Visible = false;
                txtOtherExplanation.Visible = false;
            }
        }

        protected void rdoNoToMeet_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoNoToMeet.Checked)
            {
                lblQuestionFiveOther.Visible = false;
                txtOtherExplanation.Visible = false;
            }
        }

        private bool IsMaskOnly(string text)
        {
            return System.Text.RegularExpressions.Regex.Replace(text, "[^0-9]", "").Length == 0;
        }

        protected void btnTest_Click(object sender, EventArgs e)
        {
            Response.Redirect("ThankYou.aspx");
        }

        protected void btnSubmitProposal_Click(object sender, EventArgs e)
        {
            // START OF ADDING PROJECT TO DATABASE

            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "AddProject";
            objCommand.Parameters.AddWithValue("@Title", txtQuestionOne.Text);
            objCommand.Parameters.AddWithValue("@Description", txtQuestionTwo.Text);
            string platform = "None Specified";
            if (rdoMobileApp.Checked)
            {
                platform = "Mobile App";
            }
            else if (rdoWebTool.Checked)
            {
                platform = "Web Tool";
            }
            objCommand.Parameters.AddWithValue("@Platform", platform);
            int OK_With_Timespan = 0;
            if (rdoDevelopmentYes.Checked)
            {
                OK_With_Timespan = 1;
            }
            objCommand.Parameters.AddWithValue("@OK_With_Timespan", OK_With_Timespan);
            objCommand.Parameters.AddWithValue("@Client_First_Name", txtFirstName.Text);
            objCommand.Parameters.AddWithValue("@Client_Last_Name", txtLastName.Text);
            objCommand.Parameters.AddWithValue("@Company", txtCompanyName.Text);
            objCommand.Parameters.AddWithValue("@Client_Email", txtEmail.Text);
            objCommand.Parameters.AddWithValue("@Client_Phone_Number", txtPhoneNumber.Text);
            string meetingFrequency;
            if (rdoYesToMeet.Checked) // Checked "Yes"
            {
                meetingFrequency = "Bi-weekly";
            }
            else if (rdoNoToMeet.Checked) // Checked "No"
            {
                meetingFrequency = "None Specified";
            }
            else // Other
            {
                meetingFrequency = "Other: " + txtOtherExplanation.Text;
            }
            objCommand.Parameters.AddWithValue("@Meeting_Frequency", meetingFrequency);
            int nonprofit = 0; // if (rdoNo.Checked)
            if (rdoYes.Checked)
            {
                nonprofit = 1;
            }
            objCommand.Parameters.AddWithValue("@NonProfit", nonprofit);

            int returnValue = objDB.DoUpdateUsingCmdObj(objCommand);

            // END OF ADDING PROJECT TO DATABASE

            string message = "";
            string script = "";

            if (returnValue > 0) // If Project was added
            {
                message = "<strong>Thank you for your submission, You can check the status from the landing page.</strong>";
                script = "setTimeout(function(){ window.location.href = 'Default.aspx'; }, 3500); showModalAndStartCountdown();";
            }
            else
            {
                message = "<strong>Error submitting proposal, please try again.</strong>";
                script = "setTimeout(function(){ $('#proposalModal').modal('hide'); }, 3500); showModalAndStartCountdown();";
            }

            // Update the message in the modal
            litUserInfo.Text = message;

            // Register the startup script
            ScriptManager.RegisterStartupScript(this, GetType(), "showModal", script, true);
        }
    }
}
