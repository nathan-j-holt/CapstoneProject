﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace ProjectManagement
{
    public partial class ProfessorDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session.Remove("Group_ID");
                PopulateProjects();
                PopulateApprovedProjects();
            }
        }

        private void PopulateProjects()
        {
            DBConnect db = new DBConnect();

            string storedProcedureName = "GetProjectInfo";

            SqlCommand cmd = new SqlCommand(storedProcedureName);
            cmd.CommandType = CommandType.StoredProcedure;

            DataSet dataSet = db.GetDataSet(cmd);

            // Create container div to wrap all the cards
            var containerDiv = new HtmlGenericControl("div");
            containerDiv.Attributes["style"] = "text-align: center;";

            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                // Create card structure dynamically
                var cardDiv = new HtmlGenericControl("div");
                cardDiv.Attributes["class"] = "card";
                cardDiv.Attributes["style"] = "text-align: left;";


                var cardTitleContainer = new HtmlGenericControl("div");
                cardTitleContainer.Attributes["class"] = "card-title-container";

                var cardTitle = new HtmlGenericControl("h5");
                cardTitle.Attributes["class"] = "card-title";
                cardTitle.InnerText = row["Title"].ToString();
                cardTitle.Attributes["style"] = "padding-left:1rem; color: white; padding-top: 0.5rem;";

                var cardBody = new HtmlGenericControl("div");
                cardBody.Attributes["class"] = "card-body";
                cardBody.Attributes["style"] = "height: 10rem; overflow: hidden;";

                var cardText = new HtmlGenericControl("p");
                cardText.Attributes["class"] = "card-text";
                cardText.Attributes["style"] = "height: 4.5rem; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; white-space: normal; overflow: hidden; text-overflow: ellipsis;";
                cardText.InnerText = row["Description"].ToString();

                var moreInfoBtn = new HtmlAnchor();
                moreInfoBtn.Attributes["class"] = "btn btn-primary";
                moreInfoBtn.Attributes["style"] = "color: white;";
                moreInfoBtn.InnerText = "More Info →";

                // additional MoreInforButton code
                moreInfoBtn.Attributes["data-toggle"] = "modal";
                moreInfoBtn.Attributes["data-target"] = $"#myModal-{row["Project_ID"]}"; // Unique ID for each modal
                moreInfoBtn.Attributes["runat"] = "server";

                //code for modal form
                var modalDiv = new HtmlGenericControl("div");
                modalDiv.Attributes["class"] = "modal fade";
                modalDiv.Attributes["id"] = $"myModal-{row["Project_ID"]}"; // Unique ID for each modal
                modalDiv.Attributes["tabindex"] = "-1";
                modalDiv.Attributes["role"] = "dialog";
                modalDiv.Attributes["aria-labelledby"] = $"myModalLabel-{row["Project_ID"]}";
                modalDiv.Attributes["aria-hidden"] = "true";

                var modalDialog = new HtmlGenericControl("div");
                modalDialog.Attributes["class"] = "modal-dialog modal-dialog-centered d-flex align-items-center";
                modalDialog.Attributes["role"] = "document";

                var modalContent = new HtmlGenericControl("div");
                modalContent.Attributes["class"] = "modal-content";

                // Modal header
                var modalHeader = new HtmlGenericControl("div");
                modalHeader.Attributes["class"] = "modal-header";
                modalHeader.Attributes["style"] = "border-bottom: 2px solid black; margin-left: 1rem; margin-right: 1rem;";

                var modalTitle = new HtmlGenericControl("h5");
                modalTitle.Attributes["class"] = "modal-title";
                modalTitle.Attributes["style"] = "text-align: left; margin-top: 0.5rem; margin-left: 0;";
                modalTitle.Attributes["id"] = $"myModalLabel-{row["Title"]}";
                modalTitle.InnerText = row["Title"].ToString();

                var closeButton = new HtmlGenericControl("button");
                closeButton.Attributes["type"] = "button";

                closeButton.Attributes["class"] = "close";
                closeButton.Attributes["data-dismiss"] = "modal";
                closeButton.Attributes["aria-label"] = "Close";

                var closeIcon = new HtmlGenericControl("span");
                closeIcon.Attributes["aria-hidden"] = "true";
                closeIcon.InnerText = "×";

                closeButton.Controls.Add(closeIcon);
                modalHeader.Controls.Add(modalTitle);
                modalHeader.Controls.Add(closeButton);

                // Modal body
                //Description
                var lblDescription = new HtmlGenericControl("h6");
                lblDescription.Attributes["style"] = "text-align: left; margin-left: 2rem; padding-top: 0.75rem;";
                lblDescription.InnerText = "Project Description:";

                var DescriptionBody = new HtmlGenericControl("div");
                DescriptionBody.Attributes["class"] = "modal-body";
                DescriptionBody.Attributes["style"] = "margin-left: 1rem; margin-right: 1rem; padding-top: 0rem;";
                DescriptionBody.InnerText = row["Description"].ToString();

                //Client Name
                var lblName = new HtmlGenericControl("h6");
                lblName.Attributes["style"] = "text-align: left; margin-left: 2rem; padding-top: 0.75rem;";
                lblName.InnerText = "Client Information:";

                var NameBody = new HtmlGenericControl("div");
                NameBody.Attributes["class"] = "modal-body";
                NameBody.Attributes["style"] = "margin-left: 1rem; margin-right: 1rem; padding-top: 0rem;";
                NameBody.InnerHtml = "<strong style='font-weight:500;'>Name:</strong> " + row["Client_First_Name"].ToString() + " " + row["Client_Last_Name"].ToString() + "<br />" +
                     "<strong style='font-weight:500;'>Email:</strong> " + row["Client_Email"].ToString() + "<br />" +
                     "<strong style='font-weight:500;'>Phone Number:</strong> " + row["Client_Phone_Number"].ToString();


                var lblCompany = new HtmlGenericControl("h6");
                lblCompany.Attributes["style"] = "text-align: left; margin-left: 2rem; padding-top: 0.75rem;";
                lblCompany.InnerText = "Company Information:";

                var CompanyBody = new HtmlGenericControl("div");
                CompanyBody.Attributes["class"] = "modal-body";
                CompanyBody.Attributes["style"] = "margin-left: 1rem; margin-right: 1rem; padding-top: 0rem;";
                string nonProfitText = (row["NonProfit"].ToString() == "1") ? "Yes" : "No";
                CompanyBody.InnerHtml = "<strong style='font-weight:500;'>Company:</strong> " + row["Company"].ToString() + "<br />" +
                     "<strong style='font-weight:500;'>Non-Profit:</strong> " + nonProfitText;

                var lblProjectPreferences = new HtmlGenericControl("h6");
                lblProjectPreferences.Attributes["style"] = "text-align: left; margin-left: 2rem; padding-top: 0.75rem;";
                lblProjectPreferences.InnerText = "Project Preferences:";

                var PreferenceBody = new HtmlGenericControl("div");
                PreferenceBody.Attributes["class"] = "modal-body";
                PreferenceBody.Attributes["style"] = "margin-left: 1rem; margin-right: 1rem; padding-top: 0rem;";
                string timespanText = (row["Ok_With_Timespan"].ToString() == "1") ? "Yes" : "No";
                PreferenceBody.InnerHtml = "<strong style='font-weight:500;'>Platform:</strong> " + row["Platform"].ToString() + "<br />" +
                     "<strong style='font-weight:500;'>Ok with 2 semesters:</strong> " + timespanText + "<br />" +
                     "<strong style='font-weight:500;'>Meeting Frequency:</strong> " + row["Meeting_Frequency"].ToString();


                // Modal footer (optional)
                var modalFooter = new HtmlGenericControl("div");
                modalFooter.Attributes["class"] = "modal-footer";
                modalFooter.Attributes["style"] = "border: 0;";

                var closeFooterButton = new HtmlGenericControl("button");
                closeFooterButton.Attributes["type"] = "button";
                closeFooterButton.Attributes["class"] = "btn btn-primary";
                closeFooterButton.Attributes["data-dismiss"] = "modal";
                closeFooterButton.InnerText = "Close";

                modalFooter.Controls.Add(closeFooterButton);

                // Add modal header, body, and footer to the modal content
                modalContent.Controls.Add(modalHeader);
                modalContent.Controls.Add(lblDescription);
                modalContent.Controls.Add(DescriptionBody);
                modalContent.Controls.Add(lblName);
                modalContent.Controls.Add(NameBody);
                modalContent.Controls.Add(lblCompany);
                modalContent.Controls.Add(CompanyBody);
                modalContent.Controls.Add(lblProjectPreferences);
                modalContent.Controls.Add(PreferenceBody);
                modalContent.Controls.Add(modalFooter);

                // Add modal content to the modal dialog
                modalDialog.Controls.Add(modalContent);

                // Add modal dialog to the modal div
                modalDiv.Controls.Add(modalDialog);

                // Add modal div to the placeholder
                phProjects.Controls.Add(modalDiv);


                // Add card elements to the card title container
                cardTitleContainer.Controls.Add(cardTitle);

                // Add card elements to the card body
                cardBody.Controls.Add(cardText);
                cardBody.Controls.Add(moreInfoBtn);

                // Add the card title container and card body to the card div
                cardDiv.Controls.Add(cardTitleContainer);
                cardDiv.Controls.Add(cardBody);

                // Add the card div to the container
                containerDiv.Controls.Add(cardDiv);
            }

            // Add the container to the placeholder
            phProjects.Controls.Add(containerDiv);
        }

        private void PopulateApprovedProjects()
        {
            DBConnect db = new DBConnect();

            string storedProcedureName = "GetApprovedProjects";

            SqlCommand cmd = new SqlCommand(storedProcedureName);
            cmd.CommandType = CommandType.StoredProcedure;

            DataSet dataSet = db.GetDataSet(cmd);

            // Create container div to wrap all the cards
            var containerDiv = new HtmlGenericControl("div");
            containerDiv.Attributes["style"] = "text-align: center;";

            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                // Create card structure dynamically
                var cardDiv = new HtmlGenericControl("div");
                cardDiv.Attributes["class"] = "card";
                cardDiv.Attributes["style"] = "text-align: left;";


                var cardTitleContainer = new HtmlGenericControl("div");
                cardTitleContainer.Attributes["class"] = "card-title-container";

                var cardTitle = new HtmlGenericControl("h5");
                cardTitle.Attributes["class"] = "card-title";
                cardTitle.InnerText = row["Title"].ToString();
                cardTitle.Attributes["style"] = "padding-left:1rem; color: white; padding-top: 0.5rem;";

                var cardBody = new HtmlGenericControl("div");
                cardBody.Attributes["class"] = "card-body";
                cardBody.Attributes["style"] = "height: 10rem; overflow: hidden;";

                var cardText = new HtmlGenericControl("p");
                cardText.Attributes["class"] = "card-text";
                cardText.Attributes["style"] = "height: 4.5rem; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; white-space: normal; overflow: hidden; text-overflow: ellipsis;";
                cardText.InnerText = row["Description"].ToString();

                var moreInfoBtn = new HtmlAnchor();
                moreInfoBtn.Attributes["class"] = "btn btn-primary";
                moreInfoBtn.Attributes["style"] = "color: white;";
                moreInfoBtn.InnerText = "More Info →";

                // additional MoreInforButton code
                moreInfoBtn.Attributes["data-toggle"] = "modal";
                moreInfoBtn.Attributes["data-target"] = $"#myModal-{row["Project_ID"]}"; // Unique ID for each modal
                moreInfoBtn.Attributes["runat"] = "server";

                //code for modal form
                var modalDiv = new HtmlGenericControl("div");
                modalDiv.Attributes["class"] = "modal fade";
                modalDiv.Attributes["id"] = $"myModal-{row["Project_ID"]}"; // Unique ID for each modal
                modalDiv.Attributes["tabindex"] = "-1";
                modalDiv.Attributes["role"] = "dialog";
                modalDiv.Attributes["aria-labelledby"] = $"myModalLabel-{row["Project_ID"]}";
                modalDiv.Attributes["aria-hidden"] = "true";

                var modalDialog = new HtmlGenericControl("div");
                modalDialog.Attributes["class"] = "modal-dialog modal-dialog-centered d-flex align-items-center";
                modalDialog.Attributes["role"] = "document";

                var modalContent = new HtmlGenericControl("div");
                modalContent.Attributes["class"] = "modal-content";

                // Modal header
                var modalHeader = new HtmlGenericControl("div");
                modalHeader.Attributes["class"] = "modal-header";
                modalHeader.Attributes["style"] = "border-bottom: 2px solid black; margin-left: 1rem; margin-right: 1rem;";

                var modalTitle = new HtmlGenericControl("h5");
                modalTitle.Attributes["class"] = "modal-title";
                modalTitle.Attributes["style"] = "text-align: left; margin-top: 0.5rem; margin-left: 0;";
                modalTitle.Attributes["id"] = $"myModalLabel-{row["Title"]}";
                modalTitle.InnerText = row["Title"].ToString();

                var closeButton = new HtmlGenericControl("button");
                closeButton.Attributes["type"] = "button";

                closeButton.Attributes["class"] = "close";
                closeButton.Attributes["data-dismiss"] = "modal";
                closeButton.Attributes["aria-label"] = "Close";

                var closeIcon = new HtmlGenericControl("span");
                closeIcon.Attributes["aria-hidden"] = "true";
                closeIcon.InnerText = "×";

                closeButton.Controls.Add(closeIcon);
                modalHeader.Controls.Add(modalTitle);
                modalHeader.Controls.Add(closeButton);

                // Modal body
                //Description
                var lblDescription = new HtmlGenericControl("h6");
                lblDescription.Attributes["style"] = "text-align: left; margin-left: 2rem; padding-top: 0.75rem;";
                lblDescription.InnerText = "Project Description:";

                var DescriptionBody = new HtmlGenericControl("div");
                DescriptionBody.Attributes["class"] = "modal-body";
                DescriptionBody.Attributes["style"] = "margin-left: 1rem; margin-right: 1rem; padding-top: 0rem;";
                DescriptionBody.InnerText = row["Description"].ToString();

                //Client Name
                var lblName = new HtmlGenericControl("h6");
                lblName.Attributes["style"] = "text-align: left; margin-left: 2rem; padding-top: 0.75rem;";
                lblName.InnerText = "Client Information:";

                var NameBody = new HtmlGenericControl("div");
                NameBody.Attributes["class"] = "modal-body";
                NameBody.Attributes["style"] = "margin-left: 1rem; margin-right: 1rem; padding-top: 0rem;";
                NameBody.InnerHtml = "<strong style='font-weight:500;'>Name:</strong> " + row["Client_First_Name"].ToString() + " " + row["Client_Last_Name"].ToString() + "<br />" +
                     "<strong style='font-weight:500;'>Email:</strong> " + row["Client_Email"].ToString() + "<br />" +
                     "<strong style='font-weight:500;'>Phone Number:</strong> " + row["Client_Phone_Number"].ToString();


                var lblCompany = new HtmlGenericControl("h6");
                lblCompany.Attributes["style"] = "text-align: left; margin-left: 2rem; padding-top: 0.75rem;";
                lblCompany.InnerText = "Company Information:";

                var CompanyBody = new HtmlGenericControl("div");
                CompanyBody.Attributes["class"] = "modal-body";
                CompanyBody.Attributes["style"] = "margin-left: 1rem; margin-right: 1rem; padding-top: 0rem;";
                string nonProfitText = (row["NonProfit"].ToString() == "1") ? "Yes" : "No";
                CompanyBody.InnerHtml = "<strong style='font-weight:500;'>Company:</strong> " + row["Company"].ToString() + "<br />" +
                     "<strong style='font-weight:500;'>Non-Profit:</strong> " + nonProfitText;

                var lblProjectPreferences = new HtmlGenericControl("h6");
                lblProjectPreferences.Attributes["style"] = "text-align: left; margin-left: 2rem; padding-top: 0.75rem;";
                lblProjectPreferences.InnerText = "Project Preferences:";

                var PreferenceBody = new HtmlGenericControl("div");
                PreferenceBody.Attributes["class"] = "modal-body";
                PreferenceBody.Attributes["style"] = "margin-left: 1rem; margin-right: 1rem; padding-top: 0rem;";
                string timespanText = (row["Ok_With_Timespan"].ToString() == "1") ? "Yes" : "No";
                PreferenceBody.InnerHtml = "<strong style='font-weight:500;'>Platform:</strong> " + row["Platform"].ToString() + "<br />" +
                     "<strong style='font-weight:500;'>Ok with 2 semesters:</strong> " + timespanText + "<br />" +
                     "<strong style='font-weight:500;'>Meeting Frequency:</strong> " + row["Meeting_Frequency"].ToString();


                // Modal footer (optional)
                var modalFooter = new HtmlGenericControl("div");
                modalFooter.Attributes["class"] = "modal-footer";
                modalFooter.Attributes["style"] = "border: 0;";

                // Add modal header, body, and footer to the modal content
                modalContent.Controls.Add(modalHeader);
                modalContent.Controls.Add(lblDescription);
                modalContent.Controls.Add(DescriptionBody);
                modalContent.Controls.Add(lblName);
                modalContent.Controls.Add(NameBody);
                modalContent.Controls.Add(lblCompany);
                modalContent.Controls.Add(CompanyBody);
                modalContent.Controls.Add(lblProjectPreferences);
                modalContent.Controls.Add(PreferenceBody);
                modalContent.Controls.Add(modalFooter);

                var closeFooterButton = new HtmlGenericControl("button");
                closeFooterButton.Attributes["type"] = "button";
                closeFooterButton.Attributes["class"] = "btn btn-primary";
                closeFooterButton.Attributes["data-dismiss"] = "modal";
                closeFooterButton.InnerText = "Close";

                modalFooter.Controls.Add(closeFooterButton);

                // Add modal content to the modal dialog
                modalDialog.Controls.Add(modalContent);

                // Add modal dialog to the modal div
                modalDiv.Controls.Add(modalDialog);


                // Add modal div to the placeholder
                phApprovedProjects.Controls.Add(modalDiv);


                // Add card elements to the card title container
                cardTitleContainer.Controls.Add(cardTitle);

                // Add card elements to the card body
                cardBody.Controls.Add(cardText);
                cardBody.Controls.Add(moreInfoBtn);

                // Add the card title container and card body to the card div
                cardDiv.Controls.Add(cardTitleContainer);
                cardDiv.Controls.Add(cardBody);

                // Add the card div to the container
                containerDiv.Controls.Add(cardDiv);

            }

            // Add the container to the placeholder
            phApprovedProjects.Controls.Add(containerDiv);

        }
    }
}
