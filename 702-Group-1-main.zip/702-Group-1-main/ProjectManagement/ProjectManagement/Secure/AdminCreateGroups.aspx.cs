﻿using ProjectManagement.Classes;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectManagement.Secure
{
    public partial class AdminCreateGroups : System.Web.UI.Page
    {
        protected string SelectedRowIndex
        {
            get { return hfSelectedRow.Value; }
            set { hfSelectedRow.Value = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                FillApprovedProjectsDDL();
                ShowGroups();
                if (Session["Group_ID"] != null)
                {
                    ShowStudents();
                }
            }
            else if (IsPostBack)
            {
                string script = string.Format("highlightRow(document.getElementById('{0}').rows[{1}]);", gvGroups.ClientID, SelectedRowIndex);
                ScriptManager.RegisterStartupScript(this, GetType(), "HighlightScript", script, true);
            }
        }

        private void ShowGroups()
        {
            DBConnect db = new DBConnect();
            string storedProcedureName = "GetGroupInfo";
            SqlCommand cmd = new SqlCommand(storedProcedureName);

            cmd.CommandType = CommandType.StoredProcedure;

            DataSet dataSet = db.GetDataSet(cmd);

            gvGroups.DataSource = dataSet;
            gvGroups.DataBind();
        }

        protected void gvGroups_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Select")
            {
                Session["Group_ID"] = e.CommandArgument.ToString();
                ShowGroup(int.Parse(Session["Group_ID"].ToString()));
                ShowStudents();
            }
            else if(e.CommandName == "Remove")
            {
                int groupID = Convert.ToInt32(e.CommandArgument);
                DeleteGroup(groupID);

                ScriptManager.RegisterStartupScript(this, this.GetType(), "ReloadPage", "location.reload();", true);
                Session.Remove("Group_ID");
                ShowGroups();
            }
        }

        private void ShowStudents()
        {
            DBConnect db = new DBConnect();
            string storedProcedureName = "GetAllStudents";
            SqlCommand cmd = new SqlCommand(storedProcedureName);

            cmd.CommandType = CommandType.StoredProcedure;

            DataSet dataSet = db.GetDataSet(cmd);

            gvStudents.DataSource = dataSet;
            gvStudents.DataBind();
        }

        private void ShowGroup(int group_ID)
        {
            DBConnect db = new DBConnect();
            string storedProcedureName = "GetStudentByGroupID";
            SqlCommand cmd = new SqlCommand(storedProcedureName);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Group_ID", group_ID);
            DataSet dataSet = db.GetDataSet(cmd);

            if (dataSet.Tables[0].Rows.Count > 0)
            {
                gvStudentsInGroup.DataSource = dataSet;
                gvStudentsInGroup.DataBind();

                gvStudentsInGroup.Visible = true;
            }
            else
            {
                gvStudentsInGroup.Visible = false;
            }
        }

        protected void gvStudentsInGroup_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Remove")
            {
                string AccessNet_Username = e.CommandArgument.ToString();
                RemoveStudent(AccessNet_Username);
                ShowGroup(int.Parse(Session["Group_ID"].ToString()));
                ShowStudents();
            }
        }

        private void DeleteGroup(int Group_ID)
        {
            DBConnect db = new DBConnect();
            string storedProcedureName = "DeleteGroup";
            SqlCommand cmd = new SqlCommand(storedProcedureName);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Group_ID", Group_ID);

            db.DoUpdateUsingCmdObj(cmd);
        }

        private void RemoveStudent(string accessNet_Username)
        {
            DBConnect db = new DBConnect();
            string storedProcedureName = "RemoveStudentFromGroup";
            SqlCommand cmd = new SqlCommand(storedProcedureName);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@AccessNet_Username", accessNet_Username);

            db.DoUpdateUsingCmdObj(cmd);

            ShowGroup(int.Parse(Session["Group_ID"].ToString()));
        }

        private void FillApprovedProjectsDDL()
        {
            DBConnect db = new DBConnect();
            string storedProcedureName = "GetApprovedProjectsWithoutGroup";
            SqlCommand cmd = new SqlCommand(storedProcedureName);
            cmd.CommandType = CommandType.StoredProcedure;

            DataSet dataSet = db.GetDataSet(cmd);

            ddlApprovedProjects.DataSource = dataSet;
            ddlApprovedProjects.DataTextField = "Title";
            ddlApprovedProjects.DataValueField = "Project_ID";
            ddlApprovedProjects.DataBind();
        }

        protected void btnCreateGroup_Click(object sender, EventArgs e)
        {
            DBConnect db = new DBConnect();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "CreateGroupWithProject";
            cmd.Parameters.AddWithValue("@Project_ID", ddlApprovedProjects.SelectedValue);
            cmd.Parameters.AddWithValue("@Project_Name", ddlApprovedProjects.SelectedItem.ToString());
            int returnValue = db.DoUpdateUsingCmdObj(cmd);

            ScriptManager.RegisterStartupScript(this, this.GetType(), "ReloadPage", "location.reload();", true);
            Session.Remove("Group_ID");
            ShowGroups();
        }

        protected void AddStudent(string AccessNet_Username, int group_ID)
        {
            DBConnect db = new DBConnect();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "AddStudentToGroup";
            cmd.Parameters.AddWithValue("@Group_ID", group_ID);
            cmd.Parameters.AddWithValue("@AccessNet_Username", AccessNet_Username);
            int returnValue = db.DoUpdateUsingCmdObj(cmd);
        }

        protected void gvStudents_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Add")
            {
                string AccessNet_Username = e.CommandArgument.ToString();
                AddStudent(AccessNet_Username, int.Parse(Session["Group_ID"].ToString()));
                ShowGroup(int.Parse(Session["Group_ID"].ToString()));
                ShowStudents();
            }
        }
    }
}