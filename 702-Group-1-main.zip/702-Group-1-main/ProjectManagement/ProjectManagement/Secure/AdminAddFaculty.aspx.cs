﻿using ProjectManagement.Classes;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.UI.WebControls;

namespace ProjectManagement.Secure
{
    public partial class AdminAddFaculty : System.Web.UI.Page
    {
        public bool addedProfessor;
        public bool addedAdmin;
        public bool removedProfessor;
        public bool removedAdmin;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session.Remove("Group_ID");
                ShowProfessors();
                ShowAdmin();
            }
        }

        private void ShowProfessors()
        {
            DBConnect db = new DBConnect();

            string storedProcedureName = "GetProfessors";

            SqlCommand cmd = new SqlCommand(storedProcedureName);
            cmd.CommandType = CommandType.StoredProcedure;

            DataSet dataSet = db.GetDataSet(cmd);

            gvProfessors.DataSource = dataSet;
            gvProfessors.DataBind();
        }

        private void ShowAdmin()
        {
            DBConnect db = new DBConnect();

            string storedProcedureName = "GetAdmin";

            SqlCommand cmd = new SqlCommand(storedProcedureName);
            cmd.CommandType = CommandType.StoredProcedure;

            DataSet dataSet = db.GetDataSet(cmd);

            gvAdmin.DataSource = dataSet;
            gvAdmin.DataBind();


        }

        private void AddFaculty(string AccessNet_Username, string role)
        {
            DBConnect objDB = new DBConnect();
            SqlCommand objCommand = new SqlCommand();

            if (role == "Admin")
            {
                objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "AddAdminByAccessNet";
                objCommand.Parameters.AddWithValue("@AccessNet_Username", AccessNet_Username);
                int returnValue = objDB.DoUpdateUsingCmdObj(objCommand);

                if (returnValue > 0)
                {
                    addedAdmin = true;
                }

                else
                {
                    addedAdmin = false;
                }
            }
            else if (role == "Professor")
            {
                objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "AddProfessorByAccessNet";
                objCommand.Parameters.AddWithValue("@AccessNet_Username", AccessNet_Username);
                int returnValue = objDB.DoUpdateUsingCmdObj(objCommand);

                if (returnValue > 0)
                {
                    addedProfessor = true;
                }

                else
                {
                    addedProfessor = false;
                }
            }

            ShowProfessors();
            ShowAdmin();

        }

        protected void btnAddFaculty_Click(object sender, EventArgs e)
        {
            string AccessNet_Username = txtAccessNet.Text;
            string role = null;

            if (radAdmin.Checked)
            {
                role = "Admin";
            }
            else if (radProfessor.Checked)
            {
                role = "Professor";

            }

            AddFaculty(AccessNet_Username, role);
            txtAccessNet.Text = "TUxxxxxx";
            radAdmin.Checked = false;
            radProfessor.Checked = false;
        }

        protected void gvProfessors_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Remove")
            {
                string AccessNet_Username = e.CommandArgument.ToString();
                RemoveProfessor(AccessNet_Username);

                ShowProfessors();
            }
            else if (e.CommandName == "ChangeRole")
            {
                string AccessNet_Username = e.CommandArgument.ToString();
                ChangeRoleToAdmin(AccessNet_Username);

                ShowProfessors();
                ShowAdmin();
            }
        }

        private void RemoveProfessor(string AccessNet_Username)
        {
            DBConnect db = new DBConnect();

            string storedProcedureName = "RemoveProfessor";

            SqlCommand cmd = new SqlCommand(storedProcedureName);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@AccessNet_Username", AccessNet_Username);

            db.DoUpdateUsingCmdObj(cmd);
        }

        private void ChangeRoleToAdmin(string AccessNet_Username)
        {
            DBConnect db = new DBConnect();

            string storedProcedureName = "MakeProfessorAnAdmin";

            SqlCommand cmd = new SqlCommand(storedProcedureName);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@AccessNet_Username", AccessNet_Username);

            db.DoUpdateUsingCmdObj(cmd);
            RemoveProfessor(AccessNet_Username);
        }

        protected void gvAdmins_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Remove")
            {
                string AccessNet_Username = e.CommandArgument.ToString();
                RemoveAdmin(AccessNet_Username);

                ShowAdmin();
            }
            else if (e.CommandName == "ChangeRole")
            {
                string AccessNet_Username = e.CommandArgument.ToString();
                ChangeRoleToProfessor(AccessNet_Username);

                ShowAdmin();
                ShowProfessors();              
            }
        }

        private void RemoveAdmin(string AccessNet_Username)
        {
            DBConnect db = new DBConnect();

            string storedProcedureName = "RemoveAdmin";

            SqlCommand cmd = new SqlCommand(storedProcedureName);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@AccessNet_Username", AccessNet_Username);

            db.DoUpdateUsingCmdObj(cmd);
        }

        private void ChangeRoleToProfessor(string AccessNet_Username)
        {
            DBConnect db = new DBConnect();

            string storedProcedureName = "MakeAdminAProfessor";

            SqlCommand cmd = new SqlCommand(storedProcedureName);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@AccessNet_Username", AccessNet_Username);

            db.DoUpdateUsingCmdObj(cmd);
            RemoveAdmin(AccessNet_Username);
        }
    }

}