﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Runtime.Remoting.Messaging;
using System.Xml.Linq;
using System.Text.RegularExpressions;

namespace ProjectManagement.Secure
{
    public partial class StudentMyProjects : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string AccessNet_Username = Session["AccessNet_Username"].ToString();
            doesStudentHaveGroup(AccessNet_Username);
        }

        DBConnect objDB = new DBConnect();
        SqlCommand objCommand = new SqlCommand();
        private void doesStudentHaveGroup(string AccessNet_Username)
        {
            objCommand = new SqlCommand();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "DoesStudentHaveGroup";
            objCommand.Parameters.AddWithValue("@AccessNet_username", AccessNet_Username);

            DataSet student = objDB.GetDataSetUsingCmdObj(objCommand);

            if (student != null && student.Tables.Count > 0)
            {
                int count = Convert.ToInt32(student.Tables[0].Rows[0][0]);
                if (count == 0)
                {
                    studentNotInGroup();
                }
                else
                {
                    studentInGroup(AccessNet_Username);
                }
            }

        }

        private void studentNotInGroup()
        {
            HtmlGenericControl h5Message = new HtmlGenericControl("h5");
            h5Message.InnerText = "You have not been added to a group yet. Please check back at a later time.";

            phMyProject.Controls.Add(h5Message);
        }

        private void studentInGroup(string AccessNet_Username)
        {


            //Get Group ID for student
            objCommand = new SqlCommand();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "GetGroupIDbyStudent";
            objCommand.Parameters.AddWithValue("@AccessNet_username", AccessNet_Username);

            DataSet studentsGroupID = objDB.GetDataSetUsingCmdObj(objCommand);

            string groupID = studentsGroupID.Tables[0].Rows[0]["Group_ID"].ToString();

            //Use that Group ID to get the Project ID
            objCommand = new SqlCommand();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "GetProjectIDbyGroupID";
            objCommand.Parameters.AddWithValue("@Group_ID", groupID);

            DataSet groupsProjectID = objDB.GetDataSetUsingCmdObj(objCommand);

            string projecctID = groupsProjectID.Tables[0].Rows[0]["Project_ID"].ToString();


            //Use that Project ID to get all project information
            objCommand = new SqlCommand();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "GetProjectInfoByID";
            objCommand.Parameters.AddWithValue("@Project_ID", projecctID);

            DataSet groupsProjectInfo = objDB.GetDataSetUsingCmdObj(objCommand);

            //Get Group Members from Group ID
            objCommand = new SqlCommand();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "GetGroupMembers";
            objCommand.Parameters.AddWithValue("@Group_ID", groupID);

            DataSet groupsMembers = objDB.GetDataSetUsingCmdObj(objCommand);

            string groupMembers = "";
            foreach (DataRow row in groupsMembers.Tables[0].Rows)
            {
                groupMembers += row["Full_Name"].ToString() + ", " + row["Email"].ToString() + "<br />" + "<br />";
            }

            // Extracting project info
            DataRow projectRow = groupsProjectInfo.Tables[0].Rows[0];
            string projectID = projectRow["Project_ID"].ToString();
            string title = projectRow["Title"].ToString();
            string description = projectRow["Description"].ToString();
            string platform = projectRow["Platform"].ToString();
            string clientFirstName = projectRow["Client_First_Name"].ToString();
            string clientLastName = projectRow["Client_Last_Name"].ToString();
            string clientEmail = projectRow["Client_Email"].ToString();
            string clientPhoneNumber = projectRow["Client_Phone_Number"].ToString();
            string clientCompany = projectRow["Company"].ToString();


            // Create card structures for project, client, and group information
            var projectCard = CreateCard("Project Information", $"<strong>Title:</strong> {title}<br/>" +
                                                              $"<strong>Description:</strong> {description}<br/>" +
                                                              $"<strong>Platform:</strong> {platform}");
            var clientCard = CreateCard("Client Information", $"<strong>First Name:</strong> {clientFirstName}<br/>" +
                                                              $"<strong>Last Name:</strong> {clientLastName}<br/>" +
                                                              $"<strong>Email:</strong> {clientEmail}<br/>" +
                                                              $"<strong>Phone Number:</strong> {clientPhoneNumber}<br/>" +
                                                              $"<strong>Company:</strong> {clientCompany}");
            var groupCard = CreateCard("Group Information", groupMembers);

            phMyProject.Controls.Add(projectCard);
            phMyProject.Controls.Add(clientCard);
            phMyProject.Controls.Add(groupCard);

        }
        // Function to create a card dynamically
        private HtmlGenericControl CreateCard(string title, string content)
        {
            var cardDiv = new HtmlGenericControl("div");
            cardDiv.Attributes["class"] = "static-card";
            cardDiv.Attributes["style"] = "text-align: left;";

            var cardTitleContainer = new HtmlGenericControl("div");
            cardTitleContainer.Attributes["class"] = "static-card-title-container";

            var cardTitle = new HtmlGenericControl("h5");
            cardTitle.Attributes["class"] = "static-card-title";
            cardTitle.InnerText = title;
            cardTitle.Attributes["style"] = "padding-left:1rem; color: white; padding-top: 0.5rem;";

            var cardBody = new HtmlGenericControl("div");
            cardBody.Attributes["class"] = "static-card-body";

            var cardText = new HtmlGenericControl("p");
            cardText.Attributes["class"] = "static-card-text";
            cardText.InnerHtml = content;

            cardTitleContainer.Controls.Add(cardTitle);
            cardBody.Controls.Add(cardText);
            cardDiv.Controls.Add(cardTitleContainer);
            cardDiv.Controls.Add(cardBody);

            // JavaScript to adjust card heights
            cardDiv.Attributes.Add("onload", "adjustCardHeights()");

            return cardDiv;
        }



    }
}
