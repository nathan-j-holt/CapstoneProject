﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectManagement.Secure
{
    public class Shibboleth
    {
    }
}