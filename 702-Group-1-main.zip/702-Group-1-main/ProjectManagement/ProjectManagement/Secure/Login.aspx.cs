﻿using ProjectManagement.Classes;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;

namespace ProjectManagement.Secure
{
    public partial class Login : System.Web.UI.Page
    {
        public bool addedStudent;
        public bool addedProfessor;
        public bool addedAdmin;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Variables
            string employeeNumber = string.Empty;

            /* Check if the application is running demo mode */
            //if (ConfigurationManager.AppSettings["demo_mode"].ToLower().Equals("false"))
            //{
            /* Check if the application is running locally for development
             * Retrieve request header information
             */
            if (HttpContext.Current.Request.IsLocal.Equals(true))
            {
                /*The SSO Sign-on page will not appear while running locally. This is only used for development.*/
                //student ID's to test

                //Kevin's ID: Should redirect to student
                //employeeNumber = "915733356";

                //Kyrsch's ID: Should redirect to student
                employeeNumber = "915618600";

                //Nathan's ID: Set to Professor
                //employeeNumber = "915787404";


                //Michael's ID: Set to Admin
                //employeeNumber = "915732834";

                //Rob
                employeeNumber = "915154407";
            }
            else
            {
                /*Application is running on server and the user has active Shibboleth session.*/
                employeeNumber = GetShibbolethHeaderAttributes();
            }

            /*Use employee number to get user information from web services and then redirect*/
            GetUserInformation(employeeNumber);

            //}
        }

        /// <summary>
        /// Retrieve user information from Shibboleth headers
        /// </summary>
        /// <returns>User's TUid</returns>
        protected string GetShibbolethHeaderAttributes()
        {
            string employeeNumber = Request.Headers["employeeNumber"]; //Use this to retrieve the user's information via the web services  
            Session["SSO_Attribute_employeeNumber"] = employeeNumber;


            // The following 4 lines of code are also attributes returned via Shibboleth, but can also be retrieved for ITS soap web services
            Session["SSO_Attribute_affiliation"] = Request.Headers["affiliation"];
            Session["SSO_Attribute_eduPersonPrincipalName"] = Request.Headers["eppn"];
            Session["SSO_Attribute_mail"] = Request.Headers["mail"];
            Session["SSO_Attribute_remote_user"] = Request.Headers["remoteuser"];


            //This is for display purposes only so you can see what is returned in the request headers and not needed for application development
            Session["HTTP_Request_Headers"] = RetrieveHTTPHeaders();

            return (String.IsNullOrWhiteSpace(employeeNumber)) ? "N/A" : employeeNumber;
        }

        private string RetrieveHTTPHeaders()
        {
            StringBuilder headers = new StringBuilder();
            foreach (var key in Request.Headers.AllKeys)
                headers.Append(key + "=" + Request.Headers[key] + "\n");

            return headers.ToString();
        }

        /// <summary>
        /// Use employeeNumber (TUid) to retrieve information about the user
        /// from the web services.
        /// </summary>
        /// <param name="employeeNumber">TUid</param>
        protected void GetUserInformation(string employeeNumber)
        {
            if (!string.IsNullOrWhiteSpace(employeeNumber))
            {
                /*Security Session Variable*/
                Session["Authenticated"] = true;

                /* Requesting user's LDAP information via Web Service */
                WebService.LDAPuser Temple_Information = WebService.Webservice.getLDAPEntryByTUID(employeeNumber);


                /* Checking we received something from Web Services*/
                if (Temple_Information != null)
                {
                    /*Populating the Session Object with the user's information*/
                    Session["TU_ID"] = Temple_Information.templeEduID;
                    Session["First_Name"] = Temple_Information.givenName;
                    Session["Last_Name"] = Temple_Information.sn;
                    Session["Email"] = Temple_Information.mail;
                    Session["Title"] = Temple_Information.title;
                    Session["Affiliation_Primary"] = Temple_Information.eduPersonPrimaryAffiliation;
                    Session["Affiliation_Secondary"] = Temple_Information.eduPersonAffiliation;
                    Session["Full_Name"] = Temple_Information.cn;
                    Session["AccessNet_Username"] = Temple_Information.uID;

                    /* If the user is a student, we can request academic information via the Web Service */
                    WebService.StudentObj Student_Information = WebService.Webservice.getStudentInfo(Temple_Information.templeEduID);

                    /* Checking we received something from Web Service and then adding information to the Session Object*/
                    if (Student_Information != null)
                    {
                        Session["School"] = Student_Information.school;
                        Session["Major_1"] = Student_Information.major1;
                        Session["Major_2"] = Student_Information.major2;
                    }

                    IsAdminExists(Session["AccessNet_Username"].ToString());
                    IsProfessorExists(Session["AccessNet_Username"].ToString());
                    IsStudentExist(Session["AccessNet_Username"].ToString());

                }
                else
                {
                    //Error: Couldn't retrieve employeeNumber from request header
                    throw new HttpException(403, "EmployeeNumber could not be retrieved");
                }
            }
        }

        /// <summary>
        /// Spoof user to look like my information.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEmployeeTestAcct_Click(object sender, EventArgs e)
        {
            try
            {
                GetUserInformation("888000088");
            }
            catch (Exception)
            {
                Server.Transfer("500http.aspx");
            }
        }

        /// <summary>
        /// Spoof test account
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnStudentTestAcct_Click(object sender, EventArgs e)
        {
            try
            {
                GetUserInformation("888000089");
            }
            catch (Exception)
            {
                Server.Transfer("500http.aspx");
            }
        }


        /// <summary>
        /// Use shibboleth if application is running demo_mode, but also not running locally.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShibb_Click(object sender, EventArgs e)
        {
            try
            {
                if (Request.Headers["employeeNumber"] != null)
                {
                    GetUserInformation(Request.Headers["employeeNumber"]);
                }
                else
                {

                    /*divError.Visible = true;
                    lblError.Text = (HttpContext.Current.Request.IsLocal.Equals(true)) ? "<strong>Error:</strong> Shibboleth cannot be used if application is running locally." : "<strong>Error:</strong> Profile could not be loaded!";*/
                }
            }
            catch (Exception)
            {
                Server.Transfer("500http.aspx");
            }
        }

        DBConnect objDB = new DBConnect();
        SqlCommand objCommand = new SqlCommand();

        public Boolean AddStudent()
        {
            string TUID = Session["TU_ID"].ToString();
            string First_Name = Session["First_Name"].ToString();
            string Last_Name = Session["Last_Name"].ToString();
            string Full_Name = Session["Full_Name"].ToString();
            string Email = Session["Email"].ToString();
            string AccessNet_Username = Session["AccessNet_Username"].ToString();

            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "AddStudentToTable";
            objCommand.Parameters.AddWithValue("@TUID", TUID);
            objCommand.Parameters.AddWithValue("@First_Name", First_Name);
            objCommand.Parameters.AddWithValue("@Last_Name", Last_Name);
            objCommand.Parameters.AddWithValue("@Full_Name", Full_Name);
            objCommand.Parameters.AddWithValue("@Email", Email);
            objCommand.Parameters.AddWithValue("@AccessNet_Username", AccessNet_Username);
            int returnValue = objDB.DoUpdateUsingCmdObj(objCommand);

            if (returnValue > 0)
            {
                addedStudent = true;
            }

            else
            {
                addedStudent = false;
            }

            return addedStudent;
        }


        private void IsStudentExist(string AccessNet_Username)
        {
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "DoesStudentExist";
            objCommand.Parameters.AddWithValue("@AccessNet_Username", AccessNet_Username);

            DataSet student = objDB.GetDataSetUsingCmdObj(objCommand);

            if (student != null && student.Tables.Count > 0)
            {
                int count = Convert.ToInt32(student.Tables[0].Rows[0][0]);
                if (count == 0)
                {
                    AddStudent();
                    Response.Redirect("StudentDashboard.aspx");
                }
                else
                {
                    Response.Redirect("StudentDashboard.aspx");
                }
            }

        }

        public Boolean AddAdmin()
        {
            string TUID = Session["TU_ID"].ToString();
            string First_Name = Session["First_Name"].ToString();
            string Last_Name = Session["Last_Name"].ToString();
            string Full_Name = Session["Full_Name"].ToString();
            string Email = Session["Email"].ToString();
            string AccessNet_Username = Session["AccessNet_Username"].ToString();

                objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "AddAdminToTable";
                objCommand.Parameters.AddWithValue("@TUID", TUID);
                objCommand.Parameters.AddWithValue("@First_Name", First_Name);
                objCommand.Parameters.AddWithValue("@Last_Name", Last_Name);
                objCommand.Parameters.AddWithValue("@Full_Name", Full_Name);
                objCommand.Parameters.AddWithValue("@Email", Email);
                objCommand.Parameters.AddWithValue("@AccessNet_Username", AccessNet_Username);
                int returnValue = objDB.DoUpdateUsingCmdObj(objCommand);

                if (returnValue > 0)
                {
                    addedAdmin = true;
                }

                else
                {
                    addedAdmin = false;
                }

            return addedAdmin;
        }

        private void IsAdminExists(string AccessNet_Username)
        {
            objCommand = new SqlCommand();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "DoesAdminExist";
            objCommand.Parameters.AddWithValue("@AccessNet_username", AccessNet_Username);

            DataSet administrator = objDB.GetDataSetUsingCmdObj(objCommand);

            if (administrator != null && administrator.Tables.Count > 0)
            {
                int count = Convert.ToInt32(administrator.Tables[0].Rows[0][0]);
                if (count == 0)
                {
                    return;
                }
                else
                {
                    AddAdmin();
                    Response.Redirect("AdminDashboard.aspx");
                }
            }

        }

        public Boolean AddProfessor()
        {
            string TUID = Session["TU_ID"].ToString();
            string First_Name = Session["First_Name"].ToString();
            string Last_Name = Session["Last_Name"].ToString();
            string Full_Name = Session["Full_Name"].ToString();
            string Email = Session["Email"].ToString();
            string AccessNet_Username = Session["AccessNet_Username"].ToString();

                objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "AddProfessorToTable";
                objCommand.Parameters.AddWithValue("@TUID", TUID);
                objCommand.Parameters.AddWithValue("@First_Name", First_Name);
                objCommand.Parameters.AddWithValue("@Last_Name", Last_Name);
                objCommand.Parameters.AddWithValue("@Full_Name", Full_Name);
                objCommand.Parameters.AddWithValue("@Email", Email);
                objCommand.Parameters.AddWithValue("@AccessNet_Username", AccessNet_Username);
                int returnValue = objDB.DoUpdateUsingCmdObj(objCommand);

                if (returnValue > 0)
                {
                    addedProfessor = true;
                }

                else
                {
                    addedProfessor = false;
                }

            return addedProfessor;
        }

        private void IsProfessorExists(string AccessNet_Username)
        {
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "DoesProfessorExist";
            objCommand.Parameters.AddWithValue("@AccessNet_username", AccessNet_Username);

            DataSet professor = objDB.GetDataSetUsingCmdObj(objCommand);

            if (professor != null && professor.Tables.Count > 0)
            {
                int count = Convert.ToInt32(professor.Tables[0].Rows[0][0]);
                if (count == 0)
                {
                    return;
                }
                else
                {
                    AddProfessor();
                    Response.Redirect("ProfessorDashboard.aspx");
                }
            }
        }

    }
}