﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShibbolethClasses
{
    public class ErrorHandler
    {
        private Exception ex;

        public ErrorHandler()
        {
            ex = HttpContext.Current.Server.GetLastError();

        }
    }
}